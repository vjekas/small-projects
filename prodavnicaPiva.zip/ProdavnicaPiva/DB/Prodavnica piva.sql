DROP DATABASE IF EXISTS prodavnica_p;
CREATE DATABASE prodavnica_p DEFAULT CHARACTER SET utf8;

USE prodavnica_p;

GRANT ALL ON prodavnica_p.* TO 'prodavnica_p'@'%' IDENTIFIED BY 'prodavnica_p';

FLUSH PRIVILEGES;