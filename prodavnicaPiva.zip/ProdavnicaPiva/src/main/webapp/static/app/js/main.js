var jwdApp = angular.module('jwdApp', ['ngRoute']);

jwdApp.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl : '/static/app/html/partial/mainApp.html'
        })
        .when('/piva/edit/:id', {
            templateUrl : '/static/app/html/partial/editApp.html'
        })
        .otherwise({
            redirectTo: '/'
        });
}]);

// ******************** mainCtrl ******************** \\
jwdApp.controller("mainCtrl", function($scope, $http, $location){

    var base_url_piva = "/api/piva";
    var base_url_pivare = "/api/pivare";
    var base_url_vrste = "/api/vrste_piva";

    $scope.pageNum = 0;
    $scope.totalPages = 0;

    $scope.pivo = [];
    $scope.pivara = [];
    $scope.vrsta = [];

    // ----- ADD stavimo kao i sto je na slici za dodavanje iz DTO ----- \\
    $scope.novoPivo = {};
    $scope.novoPivo.naziv = "";
    $scope.novoPivo.vrstaId = "";
    $scope.novoPivo.procenatAlkohola = "";
    $scope.novoPivo.ibu = "";
    $scope.novoPivo.kolicinaNaStanju = "";
    $scope.novoPivo.pivaraId = "";

    // ----- Pretraga - repository back-end ----- \\
    $scope.trazenoPivo = {};
    $scope.trazenoPivo.naziv = "";
    $scope.trazenoPivo.minIbu = "";
    $scope.trazenoPivo.maxIbu = "";

    var getPivo = function(){

        var config = {params: {}};

        config.params.pageNum = $scope.pageNum;

        if($scope.trazenoPivo.naziv != ""){
            config.params.naziv = $scope.trazenoPivo.naziv;
        }

        if($scope.trazenoPivo.minIbu != ""){
            config.params.minIbu = $scope.trazenoPivo.minIbu;
        }

        if($scope.trazenoPivo.maxIbu != ""){
            config.params.maxIbu = $scope.trazenoPivo.maxIbu;
        }

        $http.get(base_url_piva, config)
            .then(function success(data){
                $scope.pivo = data.data;
                $scope.totalPages = data.headers('totalPages');

            });
    };

    var getPivara = function(){

        $http.get(base_url_pivare)
            .then(function success(data){
                $scope.pivara = data.data;
            });

    };

    var getVrsta = function(){

        $http.get(base_url_vrste)
            .then(function success(data){
                $scope.vrsta = data.data;
            });

    };

    getPivo();
    getPivara();
    getVrsta();

    $scope.nazad = function(){
        if($scope.pageNum > 0) {
            $scope.pageNum = $scope.pageNum - 1;
            getPivo();
        }
    };

    $scope.napred = function(){
        if($scope.pageNum < $scope.totalPages - 1){
            $scope.pageNum = $scope.pageNum + 1;
            getPivo();
        }
    };

    // --------------- add - dodavanje u bazu function --------------- \\
    $scope.dodaj = function(){
        $http.post(base_url_piva, $scope.novoPivo)
            .then(function success(data){
                console.log(data.data);
                alert("Uspesno dodato pivo u bazu.");
                getPivo();

                $scope.novoPivo = {};
                $scope.novoPivo.naziv = "";
                $scope.novoPivo.vrstaId = "";
                $scope.novoPivo.procenatAlkohola = "";
                $scope.novoPivo.ibu = "";
                $scope.novoPivo.kolicinaNaStanju = "";
                $scope.novoPivo.pivaraId = "";
            });
    };

     $scope.trazi = function () {
        $scope.pageNum = 0;
        getPivo();
    }

    $scope.izmeni = function(id){
        $location.path('/piva/edit/' + id);
    }
    
    // stavljamo ['delete'] da ne izbacuje gresku
    $scope.obrisi = function(id){
        $http['delete'](base_url_piva + "/" + id).then(
            function success(data){
                getPivo();
            },
            function error(data){
                alert("Neuspesno brisanje!");
                console.log(data);
            }
        );

    }
    

});

// ************************* editCtrl ************************* \\

jwdApp.controller("editCtrl", function($scope, $http, $routeParams, $location){

    var base_url_piva = "/api/piva";
    var base_url_vrste = "/api/vrste_piva";

    $scope.staroPivo = {};
    $scope.staroPivo.id = "";
    $scope.staroPivo.naziv = "";
    $scope.staroPivo.vrstaId = 0;
    $scope.staroPivo.procenatAlkohola = "";
    $scope.staroPivo.ibu = "";
    $scope.staroPivo.kolicinaNaStanju = "";

    var id = $routeParams.aid;

    // $scope.staroPivo = null;

    var getStaroPivo = function(){

        $http.get(base_url_piva + "/" + $routeParams.id)
            .then(function success(data){
               $scope.staroPivo = data.data;
            });

    };
    getStaroPivo();

    $scope.getVrstaPiva = false;
    var getVrsta = function(){

        $http.get(base_url_vrste)
            .then(function success(data){
                $scope.vrsta = data.data;
                $scope.getVrstaPiva = true;
            });

    };
    getVrsta();

    
    $scope.izmeni = function(){
        $http.put(base_url_piva + "/" + $scope.staroPivo.id, $scope.staroPivo)
            .then(function success(data){
                alert("Uspešno izmenjen objekat!");
                $scope.staroPivo.id = "";
                $scope.staroPivo.naziv = "";
                $scope.staroPivo.vrstaId = 0;
                $scope.staroPivo.procenatAlkohola = "";
                $scope.staroPivo.ibu = "";
                $scope.staroPivo.kolicinaNaStanju = "";
                $location.path("/");
            });
    }
});