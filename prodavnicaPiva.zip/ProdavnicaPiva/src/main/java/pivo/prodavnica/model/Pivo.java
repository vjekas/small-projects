package pivo.prodavnica.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Pivo {
	
	@Id
	@GeneratedValue
	@Column
	private Long id;
	@Column
	private String naziv;
	@ManyToOne(fetch = FetchType.EAGER)
	private Vrsta vrsta;
	@Column
	private Double procenatAlkohola;
	@Column
	private Double ibu;
	@Column
	private Integer kolicinaNaStanju;
	@ManyToOne(fetch = FetchType.EAGER)
	private Pivara pivara;
	
	
	
	public Pivo() {
		super();
	}
	
	public Pivo(Long id, String naziv, Vrsta vrsta, Double procenatAlkohola, Double ibu, Integer kolicinaNaStanju,
			Pivara pivara) {
		super();
		this.id = id;
		this.naziv = naziv;
		this.vrsta = vrsta;
		this.procenatAlkohola = procenatAlkohola;
		this.ibu = ibu;
		this.kolicinaNaStanju = kolicinaNaStanju;
		this.pivara = pivara;
	}
	


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Vrsta getVrsta() {
		return vrsta;
	}

	public void setVrsta(Vrsta vrsta) {
		this.vrsta = vrsta;
		if (vrsta != null && !vrsta.getVrstaPiva().contains(this)) {
			vrsta.getVrstaPiva().add(this);
		}
	}

	public Double getProcenatAlkohola() {
		return procenatAlkohola;
	}

	public void setProcenatAlkohola(Double procenatAlkohola) {
		this.procenatAlkohola = procenatAlkohola;
	}
	

	public Double getIbu() {
		return ibu;
	}

	public void setIbu(Double ibu) {
		this.ibu = ibu;
	}


	public Integer getKolicinaNaStanju() {
		return kolicinaNaStanju;
	}

	public void setKolicinaNaStanju(Integer kolicinaNaStanju) {
		this.kolicinaNaStanju = kolicinaNaStanju;
	}

	public Pivara getPivara() {
		return pivara;
	}

	public void setPivara(Pivara pivara) {
		this.pivara = pivara;
		if (pivara != null && !pivara.getPiva().contains(this)) {
			pivara.getPiva().add(this);
		}
	}

}