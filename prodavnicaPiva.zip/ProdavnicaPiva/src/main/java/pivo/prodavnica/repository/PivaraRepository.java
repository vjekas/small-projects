package pivo.prodavnica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pivo.prodavnica.model.Pivara;

public interface PivaraRepository extends JpaRepository<Pivara, Long> {

}
