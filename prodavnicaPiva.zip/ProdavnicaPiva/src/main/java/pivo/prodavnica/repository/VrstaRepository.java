package pivo.prodavnica.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pivo.prodavnica.model.Vrsta;

public interface VrstaRepository extends JpaRepository<Vrsta, Long> {

}
