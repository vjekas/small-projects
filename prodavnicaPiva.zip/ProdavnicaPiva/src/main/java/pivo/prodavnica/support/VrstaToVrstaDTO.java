package pivo.prodavnica.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import pivo.prodavnica.model.Vrsta;
import pivo.prodavnica.web.dto.VrstaDTO;

@Component
public class VrstaToVrstaDTO implements Converter<Vrsta, VrstaDTO> {

	@Override
	public VrstaDTO convert(Vrsta source) {
		VrstaDTO vrstaDTO = new VrstaDTO();
		
		vrstaDTO.setId(source.getId());
		vrstaDTO.setNaziv(source.getNaziv());
		
		return vrstaDTO;
	}
	
	public List<VrstaDTO> convert(List<Vrsta> vrste) {
		List<VrstaDTO> ret = new ArrayList<>();
		
		for (Vrsta v : vrste) {
			ret.add(convert(v));
		}
		return ret;
	}

}
