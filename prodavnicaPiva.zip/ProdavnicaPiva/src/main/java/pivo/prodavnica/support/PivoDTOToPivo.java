package pivo.prodavnica.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import pivo.prodavnica.service.PivaraService;
import pivo.prodavnica.service.PivoService;
import pivo.prodavnica.service.VrstaService;
import pivo.prodavnica.model.Pivo;
import pivo.prodavnica.web.dto.PivoDTO;

@Component
public class PivoDTOToPivo implements Converter<PivoDTO, Pivo> {
	
	@Autowired
	private PivoService pivoService;
	@Autowired
	private PivaraService pivaraService;
	@Autowired
	private VrstaService vrstaService;

	@Override
	public Pivo convert(PivoDTO source) {
		Pivo pivo;
		
		if (source.getId() == null) {
			pivo = new Pivo();
			pivo.setVrsta(vrstaService.findOne(source.getVrstaId()));
			pivo.setPivara(pivaraService.findOne(source.getPivaraId()));
		} else {
			pivo = pivoService.findOne(source.getId());
		}
		pivo.setNaziv(source.getNaziv());
		pivo.setIbu(source.getIbu());
		pivo.setProcenatAlkohola(source.getProcenatAlkohola());
		pivo.setKolicinaNaStanju(source.getKolicinaNaStanju());
		
		return pivo;
	}

}
