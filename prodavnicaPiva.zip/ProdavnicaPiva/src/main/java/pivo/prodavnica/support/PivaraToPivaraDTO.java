package pivo.prodavnica.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import pivo.prodavnica.model.Pivara;
import pivo.prodavnica.web.dto.PivaraDTO;

@Component
public class PivaraToPivaraDTO implements Converter<Pivara, PivaraDTO> {

	@Override
	public PivaraDTO convert(Pivara source) {
		PivaraDTO pivaraDTO = new PivaraDTO();
		
		pivaraDTO.setId(source.getId());
		pivaraDTO.setNaziv(source.getNaziv());
		pivaraDTO.setPib(source.getPib());
		pivaraDTO.setDrzava(source.getDrzava());
		
		return pivaraDTO;
	}
	
	public List<PivaraDTO> convert(List<Pivara> pivare) {
		List<PivaraDTO> ret = new ArrayList<>();
		
		for (Pivara p : pivare) {
			ret.add(convert(p));
		}
		return ret;
	}

}
