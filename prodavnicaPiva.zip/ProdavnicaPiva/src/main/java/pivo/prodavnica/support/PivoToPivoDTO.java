package pivo.prodavnica.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import pivo.prodavnica.model.Pivo;
import pivo.prodavnica.web.dto.PivoDTO;

@Component
public class PivoToPivoDTO implements Converter<Pivo, PivoDTO> {

	@Override
	public PivoDTO convert(Pivo source) {
		PivoDTO dto = new PivoDTO();
		
		dto.setId(source.getId());
		dto.setNaziv(source.getNaziv());
		dto.setVrstaId(source.getVrsta().getId());
		dto.setVrstaNaziv(source.getVrsta().getNaziv());
		dto.setProcenatAlkohola(source.getProcenatAlkohola());
		dto.setKolicinaNaStanju(source.getKolicinaNaStanju());
		dto.setIbu(source.getIbu());
		dto.setPivaraNaziv(source.getPivara().getNaziv());
		dto.setPivaraId(source.getPivara().getId());
		
		return dto;
	}
	
	public List<PivoDTO> convert(List<Pivo> piva) {
		List<PivoDTO> ret = new ArrayList<>();
		
		for (Pivo p : piva) {
			ret.add(convert(p));
		}
		return ret;
	}

}
