package pivo.prodavnica;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import pivo.prodavnica.service.PivaraService;
import pivo.prodavnica.service.PivoService;
import pivo.prodavnica.service.VrstaService;

@Component
public class TestData {
	
	@Autowired
	private PivoService pivoService;
	@Autowired
	private PivaraService pivaraService;
	@Autowired
	private VrstaService vrstaService;
	
	@PostConstruct
	public void init() {
		
		
	}

}
