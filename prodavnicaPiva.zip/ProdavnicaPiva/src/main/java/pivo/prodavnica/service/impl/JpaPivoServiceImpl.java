package pivo.prodavnica.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pivo.prodavnica.repository.PivoRepository;
import pivo.prodavnica.model.Pivo;
import pivo.prodavnica.service.PivoService;

@Service
@Transactional
public class JpaPivoServiceImpl implements PivoService {
	
	@Autowired
	private PivoRepository pivoRepository;

	@Override
	public Pivo findOne(Long id) {
		
		return pivoRepository.findOne(id);
	}

	@Override
	public void save(Pivo pivo) {
		pivoRepository.save(pivo);

	}

	@Override
	public void delete(Long id) {
		pivoRepository.delete(id);

	}

	@Override
	public List<Pivo> save(List<Pivo> piva) {
		
		return pivoRepository.save(piva);
	}

	@Override
	public Page<Pivo> findAll(int pageNum) {
		
		return pivoRepository.findAll(new PageRequest(pageNum, 5));
	}

	@Override
	public Page<Pivo> findByPivaraId(int pageNum, Long pivaraId) {
		
		return pivoRepository.findByPivaraId(pivaraId, new PageRequest(pageNum, 5));
	}

	@Override
	public Page<Pivo> pretraga(String naziv, Double minIbu, Double maxIbu, int page) {
		
		if (naziv != null) {
			naziv = "%" + naziv + "%";
		}
		return pivoRepository.pretraga(naziv, minIbu, maxIbu, new PageRequest(page, 5));
	}

}
