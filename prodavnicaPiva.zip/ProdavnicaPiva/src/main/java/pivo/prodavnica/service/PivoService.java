package pivo.prodavnica.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;

import pivo.prodavnica.model.Pivo;

public interface PivoService {
	
	Pivo findOne(Long id);
	
	void save(Pivo pivo);
	
	void delete(Long id);
	
	List<Pivo> save(List<Pivo> piva);
	
	Page<Pivo> findAll(int pageNum);
	
	Page<Pivo> findByPivaraId(int pageNum, Long pivaraId);
	
	Page<Pivo> pretraga(
			@Param("naziv") String naziv,
			@Param("minIbu") Double minIbu,
			@Param("maxIbu") Double maxIbu,
			int page);

}
