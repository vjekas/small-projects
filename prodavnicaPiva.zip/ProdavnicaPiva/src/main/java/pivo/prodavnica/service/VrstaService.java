package pivo.prodavnica.service;

import java.util.List;

import pivo.prodavnica.model.Vrsta;

public interface VrstaService {
	
	List<Vrsta> findAll();
	
	Vrsta findOne(Long id);
	
	void save(Vrsta vrsta);
	
	void delete(Long id);

}
