package pivo.prodavnica.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pivo.prodavnica.model.Vrsta;
import pivo.prodavnica.repository.VrstaRepository;
import pivo.prodavnica.service.VrstaService;

@Service
@Transactional
public class JpaVrstaServiceImpl implements VrstaService {
	
	@Autowired
	private VrstaRepository vrstaRepository;

	@Override
	public List<Vrsta> findAll() {
		
		return vrstaRepository.findAll();
	}

	@Override
	public Vrsta findOne(Long id) {
		
		return vrstaRepository.findOne(id);
	}

	@Override
	public void save(Vrsta vrsta) {
		vrstaRepository.save(vrsta);

	}

	@Override
	public void delete(Long id) {
		vrstaRepository.delete(id);

	}

}
