package pivo.prodavnica.web.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import pivo.prodavnica.model.Pivara;
import pivo.prodavnica.model.Pivo;
import pivo.prodavnica.service.PivaraService;
import pivo.prodavnica.service.PivoService;
import pivo.prodavnica.support.PivaraToPivaraDTO;
import pivo.prodavnica.support.PivoToPivoDTO;
import pivo.prodavnica.web.dto.PivaraDTO;
import pivo.prodavnica.web.dto.PivoDTO;

@RestController
@RequestMapping(value = "/api/pivare")
public class ApiPivaraController {
	@Autowired
	private PivaraService pivaraService;
	@Autowired
	private PivoService pivoService;
	@Autowired
	private PivoToPivoDTO toPivoDTO;
	@Autowired
	private PivaraToPivaraDTO toDTO;
	
	/************************************************   GET findAll  ************************************************************/
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<PivaraDTO>> get() {
		List<Pivara> pivare;
		
		pivare = pivaraService.findAll();
		
		return new ResponseEntity<>(toDTO.convert(pivare), HttpStatus.OK);
	}
	
	/************************************************   GET byId  ************************************************************/
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<PivaraDTO> get(@PathVariable Long id) {
		Pivara pivara = pivaraService.findOne(id);
		
		if (pivara == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<>(toDTO.convert(pivara), HttpStatus.OK);
	}
	
	/*********************************************   GET byTip/Id-tip/Nekretnina  **************************************************/
	@RequestMapping(value = "/{pivaraId}/piva", method = RequestMethod.GET)
	public ResponseEntity<List<PivoDTO>> get(@PathVariable Long pivaraId,
			@RequestParam(defaultValue = "0") int pageNum) {
		
		Page<Pivo> pivoPoPivari = pivoService.findByPivaraId(pageNum, pivaraId);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("totalPages", Integer.toString(pivoPoPivari.getTotalPages()));
		
		return new ResponseEntity<>(toPivoDTO.convert(pivoPoPivari.getContent()), headers, HttpStatus.OK);
	}
	

}

