package pivo.prodavnica.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import pivo.prodavnica.model.Pivo;
import pivo.prodavnica.service.PivoService;
import pivo.prodavnica.support.PivoDTOToPivo;
import pivo.prodavnica.support.PivoToPivoDTO;
import pivo.prodavnica.web.dto.PivoDTO;

@RestController
@RequestMapping(value = "/api/piva")
public class ApiPivoController {
	@Autowired
	private PivoService pivoService;
	@Autowired
	private PivoToPivoDTO toDTO;
	@Autowired
	private PivoDTOToPivo toPivo;
	
	/************************************************   GET findAll  ************************************************************/
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<List<PivoDTO>> get(
			@RequestParam(required=false) String naziv,
			@RequestParam(required=false) Double minIbu,
			@RequestParam(required=false) Double maxIbu,
			@RequestParam(defaultValue="0") int pageNum) {
		
		Page<Pivo> piva;
		if (naziv != null || minIbu != null || maxIbu != null) {
			piva = pivoService.pretraga(naziv, minIbu, maxIbu, pageNum);	
		} else {
			piva = pivoService.findAll(pageNum);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("totalPages", Integer.toString(piva.getTotalPages()));
		
		return new ResponseEntity<>(toDTO.convert(piva.getContent()), headers, HttpStatus.OK);
	}
	
	/************************************************   GET byId  ************************************************************/
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<PivoDTO> get(@PathVariable Long id) {
		Pivo pivo = pivoService.findOne(id);
		
		if (pivo == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<>(toDTO.convert(pivo), HttpStatus.OK);
		
	}
	
	/************************************************   DELETE byId  ************************************************************/
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<PivoDTO> delete(@PathVariable Long id) {
		pivoService.delete(id);
		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	/************************************************   POST add  ************************************************************/
	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<PivoDTO> add(@RequestBody PivoDTO newPivo) {
		
		Pivo pivo = toPivo.convert(newPivo);
		pivoService.save(pivo);
		
		return new ResponseEntity<>(toDTO.convert(pivo), HttpStatus.CREATED);
	}
	
	/************************************************   PUT edit ************************************************************/
	@RequestMapping(method = RequestMethod.PUT, value = "/{id}")
	public ResponseEntity<PivoDTO> edit(@PathVariable Long id, @RequestBody PivoDTO izmenjen) {
		
		if (!id.equals(izmenjen.getId())) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		Pivo pivo = toPivo.convert(izmenjen);
		pivoService.save(pivo);
		
		return new ResponseEntity<>(toDTO.convert(pivo), HttpStatus.OK);
	}
	
	
}
