package pivo.prodavnica.web.dto;

public class PivoDTO {
	
	private Long id;
	private String naziv;
	/**************Vrsta**************/
	private String vrstaNaziv;
	private Long vrstaId;
	
	private Double procenatAlkohola;
	private Double ibu;
	private Integer kolicinaNaStanju;
	/**************Pivara**************/
	private String pivaraNaziv;
	private Long pivaraId;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	
	public String getVrstaNaziv() {
		return vrstaNaziv;
	}
	public void setVrstaNaziv(String vrstaNaziv) {
		this.vrstaNaziv = vrstaNaziv;
	}
	public Long getVrstaId() {
		return vrstaId;
	}
	public void setVrstaId(Long vrstaId) {
		this.vrstaId = vrstaId;
	}
	public Double getProcenatAlkohola() {
		return procenatAlkohola;
	}
	public void setProcenatAlkohola(Double procenatAlkohola) {
		this.procenatAlkohola = procenatAlkohola;
	}
	public Double getIbu() {
		return ibu;
	}
	public void setIbu(Double ibu) {
		this.ibu = ibu;
	}
	public Integer getKolicinaNaStanju() {
		return kolicinaNaStanju;
	}
	public void setKolicinaNaStanju(Integer kolicinaNaStanju) {
		this.kolicinaNaStanju = kolicinaNaStanju;
	}
	public String getPivaraNaziv() {
		return pivaraNaziv;
	}
	public void setPivaraNaziv(String pivaraNaziv) {
		this.pivaraNaziv = pivaraNaziv;
	}
	public Long getPivaraId() {
		return pivaraId;
	}
	public void setPivaraId(Long pivaraId) {
		this.pivaraId = pivaraId;
	}

}
